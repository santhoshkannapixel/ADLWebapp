<h3 class="breadcrumb-title">
    <?php echo e(Route::is('admin.dashboard') ? "Dashboard" : ''); ?>

    <?php echo e(Route::is('admin.settings') ? "Settings" : ''); ?>

    <?php echo e(Route::is('user.create') ? "New User" : ""); ?>

    <?php echo e(Route::is('user.index') ? "Users List" : ""); ?>

    <?php echo e(Route::is('user.edit') ? "Edit User" : ""); ?>


    <?php echo e(Route::is('role.create') ? "New Role" : ""); ?>

    <?php echo e(Route::is('role.index') ? "Roles List" : ""); ?>

    <?php echo e(Route::is('role.edit') ? "Edit Role" : ""); ?>

</h3>
<div class="d-flex align-items-center">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e(Route::is('admin.dashboard') ? "Home" : ''); ?>

                <?php echo e(Route::is('admin.settings') ? "Settings" : ''); ?>

                <?php echo e(Route::is('user.create') ? "New User" : ""); ?>

                <?php echo e(Route::is('user.index') ? "Users List" : ""); ?>

                <?php echo e(Route::is('user.edit') ? "Edit User" : ""); ?>

    
                <?php echo e(Route::is('role.create') ? "New Role" : ""); ?>

                <?php echo e(Route::is('role.index') ? "Roles List" : ""); ?>

                <?php echo e(Route::is('role.edit') ? "Edit Role" : ""); ?>

            </li>
        </ol>
    </nav>
    <div class="dropdown ms-3 me-3 border-start ps-3">
        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="http://www.staroceans.org/w3c/img_avatar.png" alt="" width="32" height="32" class="rounded-5 me-2">
        </a>
        <ul class="dropdown-menu dropdown-menu-light text-small shadow" aria-labelledby="dropdownUser1" style="">
            <li><a class="dropdown-item" href="#"><b><?php echo e(Sentinel::getUser()->name); ?></b> <small class="badge bg-success text-white"><?php echo e(Sentinel::getUser()->roles[0]->name); ?></small></a></li>
            <li><a class="dropdown-item" href="#">Settings</a></li>
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#" onclick="return document.getElementById('logout_form').submit()">Sign out</a></li>
        </ul>
    </div>
</div><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/admin/sections/breadcrumb.blade.php ENDPATH**/ ?>