<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('admin_title'); ?></title>
    <?php echo $__env->make('styles.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="root_admin"> 
    <main>
        
            <?php echo $__env->make('admin.sections.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <div class="main-content">
            <div class="sticky-top top-nav shadow-sm w-100 p-2 px-3">
                <?php echo $__env->make('admin.sections.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="p-3">
                <?php echo $__env->yieldContent('admin_content'); ?>
            </div>
        </div>
    </main>
    <?php echo $__env->make('scripts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/layouts/admin.blade.php ENDPATH**/ ?>