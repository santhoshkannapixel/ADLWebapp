

<?php $__env->startSection('admin_settings_content'); ?>
    <div class="card custom">
        <div class="card-header">
            <div class="card-title">
                Edit User 
            </div>
            <a class="btn btn-primary"  href="<?php echo e(route('user.index')); ?>"><i class="fa fa-list"></i> User Lists</a>
        </div>
        <div class="card-body"> 
            <?php echo Form::model($user,['route' => ['user.update', $user->id], 'id' => 'role_user_form', 'method'=> 'put']); ?>

                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <label class="col-2 text-end col-form-label">Name</label>
                    <div class="col-10">
                        <?php echo Form::text('name', null, ['class' => 'form-control', 'autocomplete' => 'off']); ?>

                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-2 text-end col-form-label">Email</label>
                    <div class="col-10">
                        <?php echo Form::email('email', null, ['class' => 'form-control', 'autocomplete' => 'off']); ?>

                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-2 text-end col-form-label">Role</label>
                    <div class="col-10">
                        <?php echo Form::select('role_id',$roleDb , $userRole, ['class' =>'form-select', 'placeholder' => '-- Select Role --']); ?>

                    </div>
                </div>
                <div class="row ">
                    <div class="col-10 offset-2">
                        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-light">back</a>
                        <button type="submit" class="btn btn-primary fw-bold">Save</button>
                    </div>
                </div> 
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.settings.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/admin/settings/users/edit.blade.php ENDPATH**/ ?>