

<?php $__env->startSection('admin_settings_content'); ?> 
    <div class="card  custom"> 
        <div class="card-header">
            <div class="card-title">
                Edit Role
            </div>
            <a class="btn btn-primary"  href="<?php echo e(route('role.index')); ?>"><i class="fa fa-list"></i>  Role List</a>
        </div>
        <?php echo Form::model($role, ['route' => ['role.update',$role->id],"id" => "roleForm", 'method'=> 'put']); ?>

            <div class="card-body"> 
                <?php echo $__env->make('admin.settings.role.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="text-end card-footer">
                <a href="<?php echo e(route('role.index')); ?>" class="btn btn-light bg-white me-2">back</a>
                <button type="submit" class="btn btn-primary fw-bold">Save</button>
            </div> 
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.settings.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/admin/settings/role/edit.blade.php ENDPATH**/ ?>