

<?php $__env->startSection("auth_title"); ?> Login  <?php $__env->stopSection(); ?>

<?php $__env->startSection("auth_content"); ?>
    <form class="text-center" action="<?php echo e(route("login")); ?>" method="POST"> 
        <?php echo csrf_field(); ?>
        <img class="mb-4" src="<?php echo e(asset('public/images/logo/logo.png')); ?>"  height="57">
    
        <div class="form-floating">
            <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com">
            <label for="floatingInput">Email address</label>
        </div>

        <div class="form-floating">
            <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
            <label for="floatingPassword">Password</label>
        </div>
    
        <div class="checkbox mb-3">
            <label>
            <input type="checkbox" value="remember-me"> Remember me
            </label>
        </div>

        <button class="w-100 btn btn-lg btn-primary " type="submit">Sign in</button>

        <p class="mt-5 mb-3 text-muted">&copy; 2022-2023</p>
    </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/auth/login.blade.php ENDPATH**/ ?>