

<?php $__env->startSection('admin_title'); ?> Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
   <ul class="nav nav-gradient w-100">
      <li class="nav-item">
         <a class="nav-link <?php echo e(Route::is(['role.index','role.create', 'role.edit']) ? "active" : ""); ?>" href="<?php echo e(route('role.index')); ?>">
            <i class="fa-users fa me-2"></i>
            Roles
         </a>
      </li>
      <li class="nav-item d-flex">
         <a class="nav-link <?php echo e(Route::is(['user.index','user.create', 'user.edit']) ? "active" : ""); ?>" href="<?php echo e(route('user.index')); ?>">
            <i class="fa-user fa me-2"></i>
            Users 
         </a> 
      </li>
      <li class="nav-item">
         <a class="nav-link" href="#">
            <i class="bi bi-question-circle-fill me-2"></i>
            Help
         </a>
      </li>
   </ul>
   <div class="my-4">
      <?php echo $__env->yieldContent('admin_settings_content'); ?>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>