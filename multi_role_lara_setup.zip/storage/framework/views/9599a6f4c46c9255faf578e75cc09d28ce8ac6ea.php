

<?php $__env->startSection('admin_settings_content'); ?>
    <div class="card custom">
        <div class="card-header">
            <div class="card-title">
                Create New Users
            </div>
            <a class="btn btn-primary"  href="<?php echo e(route('user.index')); ?>"><i class="fa fa-list"></i> User Lists</a>
        </div>
        <div class="card-body"> 
            <?php echo Form::open(['route' => 'user.store', 'id' => 'role_user_form', 'method'=> 'post']); ?>

                <?php echo csrf_field(); ?>
                <?php echo $__env->make('admin.settings.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row ">
                    <div class="col-10 offset-2">
                        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-light">back</a>
                        <button type="submit" class="btn btn-primary fw-bold">Save</button>
                    </div>
                </div> 
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.settings.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ADL_admin\resources\views/admin/settings/users/create.blade.php ENDPATH**/ ?>