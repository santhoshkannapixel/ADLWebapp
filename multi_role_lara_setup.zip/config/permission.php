<?php 
return $permissions_default = [

    // Withdrawal 
    'user.view.dashboard'    =>  false,
    'user.add.dashboard'     =>  false,
    'user.edit.dashboard'    =>  false,
    'user.delete.dashboard'  =>  false,

    // Search or Add 
    'user.view.settings'    =>  false,
    'user.add.settings'     =>  false,
    'user.edit.settings'    =>  false,
    'user.delete.settings'  =>  false,

];