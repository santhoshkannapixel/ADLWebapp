@extends('layouts.admin')

@section('admin_title') Home @endsection

@section('admin_content')
   
@endsection