<?php

use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\UserController;
use Illuminate\Support\Facades\Route;
 

Route::middleware(['auth_users'])->group(function () {

    Route::group(['prefix' => 'admin'], function(){

        Route::get('/dashboard', function () {   
            return view('admin.index');  
        })->name('admin.dashboard');

        Route::get('settings', [SettingsController::class, 'index'])->name('admin.settings');
         
        // User Routes 
        Route::get('/user', [UserController::class, 'index'])->name('user.index');
        Route::post('/user', [UserController::class, 'store'])->name('user.store');
        Route::get('/user-create', [UserController::class, 'create'])->name('user.create');
        Route::post('/user-delete/{id}', [UserController::class, 'destroy'])->name('user.delete');
        Route::get('/user-edit/{id}', [UserController::class, 'edit'])->name('user.edit');
        Route::put('/user-update/{id}', [UserController::class, 'update'])->name('user.update');
        Route::get('/user-update/{id}', function () {   
            return redirect()->back();
        })->name('user.update');


         // Role Routes 
        Route::get('/role', [RoleController::class, 'index'])->name('role.index');
        Route::post('/role', [RoleController::class, 'store'])->name('role.store');
        Route::get('/role-create', [RoleController::class, 'create'])->name('role.create');
        Route::post('/role-delete/{id}', [RoleController::class, 'destroy'])->name('role.delete');
        Route::get('/role-edit/{id}', [RoleController::class, 'edit'])->name('role.edit');
        Route::put('/role-update/{id}', [RoleController::class, 'update'])->name('role.update');
        Route::get('/role-update/{id}', function () {   
            return redirect()->back();
        })->name('role.update');

    });
    
    
});

 